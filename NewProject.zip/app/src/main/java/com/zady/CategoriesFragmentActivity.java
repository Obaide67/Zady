package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.goodiebag.pinview.*;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class CategoriesFragmentActivity extends Fragment {
	
	private ArrayList<HashMap<String, Object>> categ_list = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	
	private Intent i = new Intent();
	private SharedPreferences mode;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.categories_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		listview1 = _view.findViewById(R.id.listview1);
		mode = getContext().getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		listview1.setOnScrollListener(new AbsListView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView abs, int _scrollState) {
				
			}
			
			@Override
			public void onScroll(AbsListView abs, int _firstVisibleItem, int _visibleItemCount, int _totalItemCount) {
				
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "a");
					startActivity(i);
				}
				if (_position == 1) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "b");
					startActivity(i);
				}
				if (_position == 2) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "c");
					startActivity(i);
				}
				if (_position == 3) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "d");
					startActivity(i);
				}
				if (_position == 4) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "e");
					startActivity(i);
				}
				if (_position == 5) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "f");
					startActivity(i);
				}
				if (_position == 6) {
					i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
					i.putExtra("sec", "g");
					startActivity(i);
				}
			}
		});
	}
	
	private void initializeLogic() {
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear1.setBackgroundColor(0xFFFFFFFF);
			} else {
				linear1.setBackgroundColor(0xFF0D1F29);
			}
		}
		for(int _repeat13 = 0; _repeat13 < (int)(7); _repeat13++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("a", "");
				categ_list.add(_item);
			}
		}
		listview1.setAdapter(new Listview1Adapter(categ_list));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public void _WidgetAnimation(final View _view) {
		_view.setOnTouchListener(new View.OnTouchListener() {
			    private final float scaleDown = 0.9f; // نسبة التصغير عند الضغط
			    private final long animationDuration = 150; // مدة التأثير بالمللي ثانية
			
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        switch (event.getAction()) {
					            case MotionEvent.ACTION_DOWN: // عند الضغط
					                animateView(v, scaleDown, 0.8f); // تصغير بسيط + تعتيم طفيف
					                return true;
					
					            case MotionEvent.ACTION_UP: // عند رفع الأصبع
					                animateView(v, 1f, 1f); // إعادة الحجم والتعتيم للحالة الطبيعية
					                v.performClick(); // تنفيذ onClick بعد رفع الإصبع
					                return false; // السماح بتمرير الحدث لـ onClick
					
					            case MotionEvent.ACTION_CANCEL:
					                animateView(v, 1f, 1f); // إعادة الحجم عند إلغاء اللمس
					                return false;
					
					            case MotionEvent.ACTION_MOVE:
					                return false;
					        }
				        return false;
				    }
			
			    private void animateView(View v, float scale, float alpha) {
				        v.animate()
				                .scaleX(scale)
				                .scaleY(scale)
				                .alpha(alpha)
				                .setDuration(animationDuration)
				                .setInterpolator(new DecelerateInterpolator())
				                .start();
				    }
		});
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_categ, null);
			}
			
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			
			textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			textview3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
			if (_position == 0) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF23AB49));
				imageview1.setImageResource(R.drawable.broccoli_icon);
				textview1.setText("قسم المخضر");
				textview3.setText("القسم الخاص بالمخضر طماطة، بتيتة، باذنجان...");
			}
			if (_position == 1) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFC107));
				imageview1.setImageResource(R.drawable.cheese_icon);
				textview1.setText("قسم المنتوجات الغذائية");
				textview3.setText("القسم الخاص بالمنتوجات الغذائية رز، سكر، البان...");
			}
			if (_position == 2) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFAB40));
				imageview1.setImageResource(R.drawable.drinks_ic);
				textview1.setText("قسم المشروبات");
				textview3.setText("القسم الخاص بالمشروبات الغازية والطبيعية...");
			}
			if (_position == 3) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFEF5350));
				imageview1.setImageResource(R.drawable.fruits_icon);
				textview1.setText("قسم الفواكه");
				textview3.setText("القسم الخاص بالفواكه موز، برتقال، تفاح...");
			}
			if (_position == 4) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF795548));
				imageview1.setImageResource(R.drawable.egg);
				textview1.setText("قسم الريوك");
				textview3.setText("القسم الخاص بالفطور او الريوك، البان، بيض، قشطة...");
			}
			if (_position == 5) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF06292));
				imageview1.setImageResource(R.drawable.bakery);
				textview1.setText("قسم المعجنات");
				textview3.setText("القسم الخاص بالمعجنات كيك، بقلاوة...");
			}
			if (_position == 6) {
				linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF81C784));
				imageview1.setImageResource(R.drawable.snack);
				textview1.setText("قسم الحلويات");
				textview3.setText("القسم الخاص بالحلويات اجباس بانواعها، نساتل، كرزات...");
			}
			
			return _view;
		}
	}
}