package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.goodiebag.pinview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class SettingFragmentActivity extends Fragment {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private TextView textview4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview10;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear4;
	private LinearLayout linear2;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private Switch switch1;
	private TextView textview3;
	private TextView textview6;
	private TextView textview5;
	private TextView textview8;
	private TextView textview7;
	private TextView textview9;
	private TextView textview11;
	private ImageView imageview2;
	private TextView textview12;
	private TextView textview13;
	
	private Intent ii = new Intent();
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private FirebaseAuth accountInfo;
	private OnCompleteListener<AuthResult> _accountInfo_create_user_listener;
	private OnCompleteListener<AuthResult> _accountInfo_sign_in_listener;
	private OnCompleteListener<Void> _accountInfo_reset_password_listener;
	private OnCompleteListener<Void> accountInfo_updateEmailListener;
	private OnCompleteListener<Void> accountInfo_updatePasswordListener;
	private OnCompleteListener<Void> accountInfo_emailVerificationSentListener;
	private OnCompleteListener<Void> accountInfo_deleteUserListener;
	private OnCompleteListener<Void> accountInfo_updateProfileListener;
	private OnCompleteListener<AuthResult> accountInfo_phoneAuthListener;
	private OnCompleteListener<AuthResult> accountInfo_googleSignInListener;
	
	private SharedPreferences sh;
	private SharedPreferences mode;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.setting_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		vscroll1 = _view.findViewById(R.id.vscroll1);
		linear1 = _view.findViewById(R.id.linear1);
		linear3 = _view.findViewById(R.id.linear3);
		textview4 = _view.findViewById(R.id.textview4);
		linear5 = _view.findViewById(R.id.linear5);
		linear6 = _view.findViewById(R.id.linear6);
		linear7 = _view.findViewById(R.id.linear7);
		textview10 = _view.findViewById(R.id.textview10);
		linear8 = _view.findViewById(R.id.linear8);
		linear9 = _view.findViewById(R.id.linear9);
		linear10 = _view.findViewById(R.id.linear10);
		linear11 = _view.findViewById(R.id.linear11);
		linear4 = _view.findViewById(R.id.linear4);
		linear2 = _view.findViewById(R.id.linear2);
		imageview1 = _view.findViewById(R.id.imageview1);
		textview1 = _view.findViewById(R.id.textview1);
		textview2 = _view.findViewById(R.id.textview2);
		switch1 = _view.findViewById(R.id.switch1);
		textview3 = _view.findViewById(R.id.textview3);
		textview6 = _view.findViewById(R.id.textview6);
		textview5 = _view.findViewById(R.id.textview5);
		textview8 = _view.findViewById(R.id.textview8);
		textview7 = _view.findViewById(R.id.textview7);
		textview9 = _view.findViewById(R.id.textview9);
		textview11 = _view.findViewById(R.id.textview11);
		imageview2 = _view.findViewById(R.id.imageview2);
		textview12 = _view.findViewById(R.id.textview12);
		textview13 = _view.findViewById(R.id.textview13);
		accountInfo = FirebaseAuth.getInstance();
		sh = getContext().getSharedPreferences("sh", Activity.MODE_PRIVATE);
		mode = getContext().getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog a = new com.google.android.material.bottomsheet.BottomSheetDialog(getContext());
				View lay = getActivity().getLayoutInflater().inflate(R.layout.btsh, null);
				a.setContentView(lay);
				a.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				final LinearLayout linear3  = (LinearLayout)lay.findViewById(R.id.linear3);
				final LinearLayout linear4  = (LinearLayout)lay.findViewById(R.id.linear4);
				final LinearLayout linear2  = (LinearLayout)lay.findViewById(R.id.linear2);
				final TextView textview1  = (TextView)lay.findViewById(R.id.textview1);
				final TextView textview2  = (TextView)lay.findViewById(R.id.textview2);
				final LinearLayout linear1  = (LinearLayout)lay.findViewById(R.id.linear1);
				textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
				textview2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
				if (mode.contains("mode")) {
					if (mode.getString("mode", "").equals("light")) {
						_SET_LINEAR_LAYOUTS(40, 40, 0, 0, "#FFFFFF", "#FFFFFF", 0, linear1);
						linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
						linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
						linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					} else {
						_SET_LINEAR_LAYOUTS(40, 40, 0, 0, "#0D1F29", "#0D1F29", 0, linear1);
						linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
						linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
						linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					}
				}
				textview1.setText("العربية");
				textview2.setText("English");
				linear3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						a.dismiss();
					}
				});
				linear4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						a.dismiss();
						SketchwareUtil.showMessage(getContext().getApplicationContext(), "ستتوفر في التحديثات القادمة");
					}
				});
				a.setCancelable(true);
				a.show();
			}
		});
		
		linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog a = new com.google.android.material.bottomsheet.BottomSheetDialog(getContext());
				View lay = getActivity().getLayoutInflater().inflate(R.layout.btsh1, null);
				a.setContentView(lay);
				a.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				final LinearLayout linear3  = (LinearLayout)lay.findViewById(R.id.linear3);
				final LinearLayout linear4  = (LinearLayout)lay.findViewById(R.id.linear4);
				final LinearLayout linear2  = (LinearLayout)lay.findViewById(R.id.linear2);
				final TextView textview1  = (TextView)lay.findViewById(R.id.textview1);
				final TextView textview2  = (TextView)lay.findViewById(R.id.textview2);
				final LinearLayout linear1  = (LinearLayout)lay.findViewById(R.id.linear1);
				textview1.setText("فاتح");
				textview2.setText("داكن");
				textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
				textview2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
				if (mode.contains("mode")) {
					if (mode.getString("mode", "").equals("light")) {
						linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
						linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
						linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
						_SET_LINEAR_LAYOUTS(40, 40, 0, 0, "#FFFFFF", "#FFFFFF", 0, linear1);
					} else {
						linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
						linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
						linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
						_SET_LINEAR_LAYOUTS(40, 40, 0, 0, "#0D1F29", "#0D1F29", 0, linear1);
					}
				}
				linear3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (mode.contains("mode")) {
							if (mode.getString("mode", "").equals("light")) {
								SketchwareUtil.showMessage(getContext().getApplicationContext(), "في الوضع الفاتح بالفعل!");
								((Activity) _view.getContext()).finish();
							} else {
								mode.edit().putString("mode", "light").commit();
								ii.setClass(getContext().getApplicationContext(), MainActivity.class);
								ii.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(ii);
							}
						}
					}
				});
				linear4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (mode.contains("mode")) {
							if (mode.getString("mode", "").equals("light")) {
								mode.edit().putString("mode", "dark").commit();
								ii.setClass(getContext().getApplicationContext(), MainActivity.class);
								ii.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(ii);
							} else {
								SketchwareUtil.showMessage(getContext().getApplicationContext(), "في الوضع الداكن بالفعل!");
								((Activity) _view.getContext()).finish();
							}
						}
					}
				});
				a.setCancelable(true);
				a.show();
			}
		});
		
		linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getContext().getApplicationContext(), "قريبا");
			}
		});
		
		linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ii.setClass(getContext().getApplicationContext(), AboutActivity.class);
				startActivity(ii);
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					textview2.setText(_childValue.get("name").toString());
					sh.edit().putString("usrname", _childValue.get("name").toString()).commit();
					sh.edit().putString("phone", _childValue.get("phone").toString()).commit();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		accountInfo_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_accountInfo_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_accountInfo_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_accountInfo_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview4.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview7.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview9.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview11.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview12.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview6.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				textview4.setTextColor(0xFF000000);
				textview10.setTextColor(0xFF000000);
				linear1.setBackgroundColor(0xFFFFFFFF);
				textview3.setTextColor(0xFF000000);
				textview5.setTextColor(0xFF000000);
				textview7.setTextColor(0xFF000000);
				textview9.setTextColor(0xFF000000);
				textview11.setTextColor(0xFF000000);
				textview12.setTextColor(0xFF000000);
				textview8.setText("فاتح");
			} else {
				linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				textview4.setTextColor(0xFFFFFFFF);
				textview10.setTextColor(0xFFFFFFFF);
				linear1.setBackgroundColor(0xFF0D1F29);
				textview3.setTextColor(0xFFFFFFFF);
				textview5.setTextColor(0xFFFFFFFF);
				textview7.setTextColor(0xFFFFFFFF);
				textview9.setTextColor(0xFFFFFFFF);
				textview11.setTextColor(0xFFFFFFFF);
				textview12.setTextColor(0xFFFFFFFF);
				textview8.setText("داكن");
			}
		}
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF23AB49));
	}
	
	public void _SET_LINEAR_LAYOUTS(final double _r1, final double _r2, final double _r3, final double _r4, final String _lcolor, final String _scolor, final double _swidth, final View _view) {
		Double tlr = _r1;
		Double trr = _r2;
		Double blr = _r3;
		Double brr = _r4;
		Double sw = _swidth;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_lcolor));
		s.setStroke(sw.intValue(), Color.parseColor(_scolor));
		_view.setBackground(s);
	}
	
}