package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.goodiebag.pinview.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class CartActivity extends AppCompatActivity {
	
	private String uid = "";
	private double numm = 0;
	
	private ArrayList<HashMap<String, Object>> ordList = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear_empty;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private ListView listview1;
	private TextView textview;
	private ImageView imageview3;
	private TextView textview2;
	private Button button1;
	
	private SharedPreferences shop;
	private SharedPreferences sh;
	private Intent ii = new Intent();
	private SharedPreferences mode;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.cart);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear_empty = findViewById(R.id.linear_empty);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		linear3 = findViewById(R.id.linear3);
		listview1 = findViewById(R.id.listview1);
		textview = findViewById(R.id.textview);
		imageview3 = findViewById(R.id.imageview3);
		textview2 = findViewById(R.id.textview2);
		button1 = findViewById(R.id.button1);
		shop = getSharedPreferences("shop", Activity.MODE_PRIVATE);
		sh = getSharedPreferences("sh", Activity.MODE_PRIVATE);
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (ordList.size() == 0) {
					SketchwareUtil.showMessage(getApplicationContext(), "السلة فارغة");
				} else {
					if (getIntent().getStringExtra("from").equals("send")) {
						finish();
					} else {
						ii.setClass(getApplicationContext(), SendDetailsActivity.class);
						startActivity(ii);
					}
				}
			}
		});
	}
	
	private void initializeLogic() {
		_ClickEffect(imageview1);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		uid = sh.getString("uid", "");
		if (shop.contains("order")) {
			ordList = new Gson().fromJson(shop.getString("order", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview1.setAdapter(new Listview1Adapter(ordList));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			linear2.setVisibility(View.VISIBLE);
			linear_empty.setVisibility(View.GONE);
			double totalPrice = 0.0;
			
			for (int i = 0; i < ordList.size(); i++) {
				    HashMap<String, Object> item = ordList.get(i);
				
				    // الحصول على القيمة كسلسلة
				    String totalStr = (String) item.get("total");
				
				    // إزالة أي رموز عملة
				    totalStr = totalStr.replaceAll("[^\\d.]", "");
				
				    // تحويل إلى double
				    double price = Double.parseDouble(totalStr);
				
				    // جمع السعر
				    totalPrice += price;
			}
			
			textview.setText("السعر الكلي: " + String.format("%.2f", totalPrice));
		} else {
			linear2.setVisibility(View.GONE);
			linear_empty.setVisibility(View.VISIBLE);
		}
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				textview.setTextColor(0xFF000000);
				linear3.setBackgroundColor(0xFFF2F3F5);
				linear4.setBackgroundColor(0xFFFFFFFF);
				linear_empty.setBackgroundColor(0xFFFFFFFF);
				linear2.setBackgroundColor(0xFFFFFFFF);
			} else {
				linear1.setBackgroundColor(0xFF0D1F29);
				textview.setTextColor(0xFFFFFFFF);
				linear3.setBackgroundColor(0xFF1A2A37);
				linear4.setBackgroundColor(0xFF0D1F29);
				linear_empty.setBackgroundColor(0xFF0D1F29);
				linear2.setBackgroundColor(0xFF0D1F29);
			}
		}
	}
	
	public void _Refresh(final ArrayList<HashMap<String, Object>> _ListMap) {
		Parcelable state =
		listview1.onSaveInstanceState();
		listview1.setAdapter(new Listview1Adapter(_ListMap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		listview1.onRestoreInstanceState(state);
	}
	
	
	public void _ClickEffect(final View _view) {
		TypedValue typedValue = new TypedValue();
		
		getApplicationContext().getTheme().resolveAttribute(16843868, typedValue, true);
		
		_view.setBackgroundResource(typedValue.resourceId);
		
		_view.setClickable(true);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cart_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5line = _view.findViewById(R.id.linear5line);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final TextView textview7 = _view.findViewById(R.id.textview7);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
			textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
			textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFCDD2));
			textview3.setText(ordList.get((int)_position).get("name").toString());
			textview4.setText(ordList.get((int)_position).get("quantity").toString().concat(" كغم"));
			textview6.setText(ordList.get((int)_position).get("total").toString().concat(" دينار"));
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					ordList.remove((int)(_position));
					shop.edit().putString("order", new Gson().toJson(ordList)).commit();
					_Refresh(ordList);
				}
			});
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview2.setTextColor(0xFF000000);
					textview5.setTextColor(0xFF000000);
					textview7.setTextColor(0xFF000000);
				} else {
					linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview2.setTextColor(0xFFFFFFFF);
					textview5.setTextColor(0xFFFFFFFF);
					textview7.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}