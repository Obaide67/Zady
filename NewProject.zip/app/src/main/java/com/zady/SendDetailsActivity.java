package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.goodiebag.pinview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class SendDetailsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private FloatingActionButton _fab;
	private String phone = "";
	private String message = "";
	private HashMap<String, Object> orderMap = new HashMap<>();
	private String name = "";
	private String id = "";
	private HashMap<String, Object> orD = new HashMap<>();
	private double totalPrice = 0;
	private String uid = "";
	
	private ArrayList<HashMap<String, Object>> ordList = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview2;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private TextView textview4;
	private LinearLayout linear12;
	private TextView textview5;
	private LinearLayout linear13;
	private TextView textview6;
	private LinearLayout linear14;
	private TextView textview7;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private Button button1;
	private TextView textview2;
	private TextView textview3;
	private TextView textview1;
	private EditText edittext3;
	private EditText edittext4;
	private EditText edittext5;
	private EditText edittext6;
	private TextView textview;
	private TextView textview8;
	
	private Intent iii = new Intent();
	private DatabaseReference orders = _firebase.getReference("orders");
	private ChildEventListener _orders_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private Calendar c = Calendar.getInstance();
	private FirebaseAuth accountInfo;
	private OnCompleteListener<AuthResult> _accountInfo_create_user_listener;
	private OnCompleteListener<AuthResult> _accountInfo_sign_in_listener;
	private OnCompleteListener<Void> _accountInfo_reset_password_listener;
	private OnCompleteListener<Void> accountInfo_updateEmailListener;
	private OnCompleteListener<Void> accountInfo_updatePasswordListener;
	private OnCompleteListener<Void> accountInfo_emailVerificationSentListener;
	private OnCompleteListener<Void> accountInfo_deleteUserListener;
	private OnCompleteListener<Void> accountInfo_updateProfileListener;
	private OnCompleteListener<AuthResult> accountInfo_phoneAuthListener;
	private OnCompleteListener<AuthResult> accountInfo_googleSignInListener;
	
	private SharedPreferences sh;
	private SharedPreferences shop;
	private SharedPreferences mode;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.send_details);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = findViewById(R.id._fab);
		linear1 = findViewById(R.id.linear1);
		listview2 = findViewById(R.id.listview2);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		textview4 = findViewById(R.id.textview4);
		linear12 = findViewById(R.id.linear12);
		textview5 = findViewById(R.id.textview5);
		linear13 = findViewById(R.id.linear13);
		textview6 = findViewById(R.id.textview6);
		linear14 = findViewById(R.id.linear14);
		textview7 = findViewById(R.id.textview7);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		button1 = findViewById(R.id.button1);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		textview1 = findViewById(R.id.textview1);
		edittext3 = findViewById(R.id.edittext3);
		edittext4 = findViewById(R.id.edittext4);
		edittext5 = findViewById(R.id.edittext5);
		edittext6 = findViewById(R.id.edittext6);
		textview = findViewById(R.id.textview);
		textview8 = findViewById(R.id.textview8);
		accountInfo = FirebaseAuth.getInstance();
		sh = getSharedPreferences("sh", Activity.MODE_PRIVATE);
		shop = getSharedPreferences("shop", Activity.MODE_PRIVATE);
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext3.getText().toString().equals("")) {
					((EditText)edittext3).setError("يرجى كتابة الاسم!");
				} else {
					if (edittext4.getText().toString().equals("")) {
						((EditText)edittext4).setError("يرجى كتابة رقم الهاتف!");
					} else {
						if (edittext5.getText().toString().equals("")) {
							((EditText)edittext5).setError("يرجى كتابة رقم العنوان!");
						} else {
							orderMap = new HashMap<>();
							orderMap.put("date", new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").format(c.getTime()));
							orderMap.put("name", sh.getString("usrname", ""));
							orderMap.put("order", "none");
							orderMap.put("orderID", sh.getString("uid", ""));
							orderMap.put("price", "none");
							orderMap.put("quantity", "none");
							orderMap.put("status", "قيد الإنتضار");
							orders.push().updateChildren(orderMap);
							phone = "9647716275362";
							message = "طلب جديد".concat("\n الاسم: ".concat(edittext3.getText().toString().concat(" رقم الهاتف: ".concat(edittext4.getText().toString().concat(" الموقع: ".concat(edittext5.getText().toString().concat(" المنتجات: ".concat(textview8.getText().toString().concat(" المجموع: ".concat(textview.getText().toString()))))))))));
							iii.setAction(Intent.ACTION_VIEW);
							iii.setData(Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(message)));
							startActivity(iii);
						}
					}
				}
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				iii.setClass(getApplicationContext(), CartActivity.class);
				iii.putExtra("from", "send");
				startActivity(iii);
			}
		});
		
		_orders_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		orders.addChildEventListener(_orders_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					name = _childValue.get("name").toString();
					id = _childValue.get("id").toString();
					edittext3.setText(_childValue.get("name").toString());
					edittext4.setText(_childValue.get("phone").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		accountInfo_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		accountInfo_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_accountInfo_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_accountInfo_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_accountInfo_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		c = Calendar.getInstance();
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		edittext3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		edittext4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		edittext5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		edittext6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFECB3));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
		if (shop.contains("order")) {
			ordList = new Gson().fromJson(shop.getString("order", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview2.setAdapter(new Listview2Adapter(ordList));
			((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
			double totalPrice = 0.0;
			
			for (int i = 0; i < ordList.size(); i++) {
				    HashMap<String, Object> item = ordList.get(i);
				
				    // الحصول على القيمة كسلسلة
				    String totalStr = (String) item.get("total");
				
				    // إزالة أي رموز عملة
				    totalStr = totalStr.replaceAll("[^\\d.]", "");
				
				    // تحويل إلى double
				    double price = Double.parseDouble(totalStr);
				
				    // جمع السعر
				    totalPrice += price;
			}
			
			textview.setText("السعر الكلي: " + String.format("%.2f", totalPrice));
			
			// سلسلة لتجميع النصوص
			StringBuilder productsBuilder = new StringBuilder();
			
			for (int i = 0; i < ordList.size(); i++) {
				    HashMap<String, Object> item = ordList.get(i);
				
				    // استخراج البيانات من المفاتيح
				    String name1 = (String) item.get("name");
				    String quantity = (String) item.get("quantity");
				    String total = (String) item.get("total");
				
				    // إضافة النص بشكل "اسم - كمية كغم - سعر"
				    productsBuilder.append(name1)
				                   .append(" - ")
				                   .append(quantity)
				                   .append(" كغم - دينار")
				                   .append(total)
				                   .append("\n");
			}
			
			// عرض النص في TextView
			textview8.setText(productsBuilder.toString());
			uid = sh.getString("uid", "");
		} else {
			
		}
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
				linear1.setBackgroundColor(0xFFFFFFFF);
				textview1.setTextColor(0xFF000000);
				textview4.setTextColor(0xFF000000);
				textview5.setTextColor(0xFF000000);
				textview6.setTextColor(0xFF000000);
				textview7.setTextColor(0xFF000000);
				textview.setTextColor(0xFF000000);
			} else {
				linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
				linear1.setBackgroundColor(0xFF0D1F29);
				textview1.setTextColor(0xFFFFFFFF);
				textview4.setTextColor(0xFFFFFFFF);
				textview5.setTextColor(0xFFFFFFFF);
				textview6.setTextColor(0xFFFFFFFF);
				textview7.setTextColor(0xFFFFFFFF);
				textview.setTextColor(0xFFFFFFFF);
			}
		}
	}
	
	public void _Refresh(final ArrayList<HashMap<String, Object>> _ListMap) {
		Parcelable state =
		listview2.onSaveInstanceState();
		listview2.setAdapter(new Listview2Adapter(_ListMap));
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
		listview2.onRestoreInstanceState(state);
		
		// سلسلة لتجميع النصوص
		StringBuilder productsBuilder = new StringBuilder();
		
		for (int i = 0; i < ordList.size(); i++) {
			    HashMap<String, Object> item = ordList.get(i);
			
			    // استخراج البيانات من المفاتيح
			    String name1 = (String) item.get("name");
			    String quantity = (String) item.get("quantity");
			    String total = (String) item.get("total");
			
			    // إضافة النص بشكل "اسم - كمية كغم - سعر"
			    productsBuilder.append(name1)
			                   .append(" - ")
			                   .append(quantity)
			                   .append(" كغم - دينار")
			                   .append(total)
			                   .append("\n");
		}
		
		// عرض النص في TextView
		textview8.setText(productsBuilder.toString());
		double totalPrice = 0.0;
		
		for (int i = 0; i < ordList.size(); i++) {
			    HashMap<String, Object> item = ordList.get(i);
			
			    // الحصول على القيمة كسلسلة
			    String totalStr = (String) item.get("total");
			
			    // إزالة أي رموز عملة
			    totalStr = totalStr.replaceAll("[^\\d.]", "");
			
			    // تحويل إلى double
			    double price = Double.parseDouble(totalStr);
			
			    // جمع السعر
			    totalPrice += price;
		}
		
		textview.setText("السعر الكلي: " + String.format("%.2f", totalPrice));
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.products_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			textview1.setText(ordList.get((int)_position).get("name").toString());
			textview2.setText(ordList.get((int)_position).get("total").toString().concat(" دينار"));
			textview3.setText(ordList.get((int)_position).get("quantity").toString().concat(" كغم"));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
			textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					ordList.remove((int)(_position));
					shop.edit().putString("order", new Gson().toJson(ordList)).commit();
					_Refresh(ordList);
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}