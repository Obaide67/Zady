package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.bumptech.glide.Glide;
import com.goodiebag.pinview.*;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class SearchActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double numSearch = 0;
	private double num = 0;
	private double len = 0;
	private double num1 = 0;
	private double len1 = 0;
	
	private ArrayList<HashMap<String, Object>> listVeg = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listFood = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listFru = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listDate = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listBre = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listPas = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listSwe = new ArrayList<>();
	private ArrayList<String> listStrVeg = new ArrayList<>();
	private ArrayList<String> listStrFru = new ArrayList<>();
	private ArrayList<String> listStrFood = new ArrayList<>();
	private ArrayList<String> listStrDate = new ArrayList<>();
	private ArrayList<String> listStrBre = new ArrayList<>();
	private ArrayList<String> listStrPas = new ArrayList<>();
	private ArrayList<String> listStrSwe = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private EditText edittext1;
	private ImageView imageview1;
	private TabLayout tablayout1;
	private GridView gridview1veg;
	private GridView gridview2fru;
	private GridView gridview3food;
	private GridView gridview4dat;
	private GridView gridview5break;
	private GridView gridview6pas;
	private GridView gridview7sw;
	
	private DatabaseReference vegetables = _firebase.getReference("vegetables");
	private ChildEventListener _vegetables_child_listener;
	private DatabaseReference food = _firebase.getReference("food");
	private ChildEventListener _food_child_listener;
	private DatabaseReference fruit = _firebase.getReference("fruit");
	private ChildEventListener _fruit_child_listener;
	private DatabaseReference dates = _firebase.getReference("dates");
	private ChildEventListener _dates_child_listener;
	private DatabaseReference breakfast = _firebase.getReference("breakfast");
	private ChildEventListener _breakfast_child_listener;
	private DatabaseReference pastries = _firebase.getReference("pastries");
	private ChildEventListener _pastries_child_listener;
	private DatabaseReference sweets = _firebase.getReference("sweets");
	private ChildEventListener _sweets_child_listener;
	private Intent i = new Intent();
	private SharedPreferences mode;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.search);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		edittext1 = findViewById(R.id.edittext1);
		imageview1 = findViewById(R.id.imageview1);
		tablayout1 = findViewById(R.id.tablayout1);
		gridview1veg = findViewById(R.id.gridview1veg);
		gridview2fru = findViewById(R.id.gridview2fru);
		gridview3food = findViewById(R.id.gridview3food);
		gridview4dat = findViewById(R.id.gridview4dat);
		gridview5break = findViewById(R.id.gridview5break);
		gridview6pas = findViewById(R.id.gridview6pas);
		gridview7sw = findViewById(R.id.gridview7sw);
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (numSearch == 1) {
					vegetables.addListenerForSingleValueEvent(new ValueEventListener() {
						@Override
						public void onDataChange(DataSnapshot _dataSnapshot) {
							listVeg = new ArrayList<>();
							try {
								GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
								for (DataSnapshot _data : _dataSnapshot.getChildren()) {
									HashMap<String, Object> _map = _data.getValue(_ind);
									listVeg.add(_map);
								}
							} catch (Exception _e) {
								_e.printStackTrace();
							}
							if (_charSeq.length() > 0) {
								num = listVeg.size() - 1;
								len = listVeg.size();
								for(int _repeat23 = 0; _repeat23 < (int)(len); _repeat23++) {
									if (listVeg.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
										
									} else {
										listVeg.remove((int)(num));
									}
									num--;
								}
							}
							gridview1veg.setAdapter(new Gridview1vegAdapter(listVeg));
							gridview1veg.setVisibility(View.VISIBLE);
							gridview2fru.setVisibility(View.GONE);
							gridview3food.setVisibility(View.GONE);
							gridview4dat.setVisibility(View.GONE);
							gridview5break.setVisibility(View.GONE);
							gridview6pas.setVisibility(View.GONE);
							gridview7sw.setVisibility(View.GONE);
						}
						@Override
						public void onCancelled(DatabaseError _databaseError) {
						}
					});
				} else {
					if (numSearch == 2) {
						fruit.addListenerForSingleValueEvent(new ValueEventListener() {
							@Override
							public void onDataChange(DataSnapshot _dataSnapshot) {
								listFru = new ArrayList<>();
								try {
									GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
									for (DataSnapshot _data : _dataSnapshot.getChildren()) {
										HashMap<String, Object> _map = _data.getValue(_ind);
										listFru.add(_map);
									}
								} catch (Exception _e) {
									_e.printStackTrace();
								}
								if (_charSeq.length() > 0) {
									num = listFru.size() - 1;
									len = listFru.size();
									for(int _repeat61 = 0; _repeat61 < (int)(len); _repeat61++) {
										if (listFru.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
											
										} else {
											listFru.remove((int)(num));
										}
										num--;
									}
								}
								gridview2fru.setAdapter(new Gridview2fruAdapter(listFru));
								gridview1veg.setVisibility(View.GONE);
								gridview2fru.setVisibility(View.VISIBLE);
								gridview3food.setVisibility(View.GONE);
								gridview4dat.setVisibility(View.GONE);
								gridview5break.setVisibility(View.GONE);
								gridview6pas.setVisibility(View.GONE);
								gridview7sw.setVisibility(View.GONE);
							}
							@Override
							public void onCancelled(DatabaseError _databaseError) {
							}
						});
					} else {
						if (numSearch == 3) {
							food.addListenerForSingleValueEvent(new ValueEventListener() {
								@Override
								public void onDataChange(DataSnapshot _dataSnapshot) {
									listFood = new ArrayList<>();
									try {
										GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
										for (DataSnapshot _data : _dataSnapshot.getChildren()) {
											HashMap<String, Object> _map = _data.getValue(_ind);
											listFood.add(_map);
										}
									} catch (Exception _e) {
										_e.printStackTrace();
									}
									if (_charSeq.length() > 0) {
										num = listFood.size() - 1;
										len = listFood.size();
										for(int _repeat95 = 0; _repeat95 < (int)(len); _repeat95++) {
											if (listFood.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
												
											} else {
												listFood.remove((int)(num));
											}
											num--;
										}
									}
									gridview3food.setAdapter(new Gridview3foodAdapter(listFood));
									gridview1veg.setVisibility(View.GONE);
									gridview2fru.setVisibility(View.GONE);
									gridview3food.setVisibility(View.VISIBLE);
									gridview4dat.setVisibility(View.GONE);
									gridview5break.setVisibility(View.GONE);
									gridview6pas.setVisibility(View.GONE);
									gridview7sw.setVisibility(View.GONE);
								}
								@Override
								public void onCancelled(DatabaseError _databaseError) {
								}
							});
						} else {
							if (numSearch == 4) {
								dates.addListenerForSingleValueEvent(new ValueEventListener() {
									@Override
									public void onDataChange(DataSnapshot _dataSnapshot) {
										listDate = new ArrayList<>();
										try {
											GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
											for (DataSnapshot _data : _dataSnapshot.getChildren()) {
												HashMap<String, Object> _map = _data.getValue(_ind);
												listDate.add(_map);
											}
										} catch (Exception _e) {
											_e.printStackTrace();
										}
										if (_charSeq.length() > 0) {
											num = listDate.size() - 1;
											len = listDate.size();
											for(int _repeat129 = 0; _repeat129 < (int)(len); _repeat129++) {
												if (listDate.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
													
												} else {
													listDate.remove((int)(num));
												}
												num--;
											}
										}
										gridview4dat.setAdapter(new Gridview4datAdapter(listDate));
										gridview1veg.setVisibility(View.GONE);
										gridview2fru.setVisibility(View.GONE);
										gridview3food.setVisibility(View.GONE);
										gridview4dat.setVisibility(View.VISIBLE);
										gridview5break.setVisibility(View.GONE);
										gridview6pas.setVisibility(View.GONE);
										gridview7sw.setVisibility(View.GONE);
									}
									@Override
									public void onCancelled(DatabaseError _databaseError) {
									}
								});
							} else {
								if (numSearch == 5) {
									breakfast.addListenerForSingleValueEvent(new ValueEventListener() {
										@Override
										public void onDataChange(DataSnapshot _dataSnapshot) {
											listBre = new ArrayList<>();
											try {
												GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
												for (DataSnapshot _data : _dataSnapshot.getChildren()) {
													HashMap<String, Object> _map = _data.getValue(_ind);
													listBre.add(_map);
												}
											} catch (Exception _e) {
												_e.printStackTrace();
											}
											if (_charSeq.length() > 0) {
												num = listBre.size() - 1;
												len = listBre.size();
												for(int _repeat163 = 0; _repeat163 < (int)(len); _repeat163++) {
													if (listBre.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
														
													} else {
														listBre.remove((int)(num));
													}
													num--;
												}
											}
											gridview5break.setAdapter(new Gridview5breakAdapter(listBre));
											gridview1veg.setVisibility(View.GONE);
											gridview2fru.setVisibility(View.GONE);
											gridview3food.setVisibility(View.GONE);
											gridview4dat.setVisibility(View.GONE);
											gridview5break.setVisibility(View.VISIBLE);
											gridview6pas.setVisibility(View.GONE);
											gridview7sw.setVisibility(View.GONE);
										}
										@Override
										public void onCancelled(DatabaseError _databaseError) {
										}
									});
								} else {
									if (numSearch == 6) {
										pastries.addListenerForSingleValueEvent(new ValueEventListener() {
											@Override
											public void onDataChange(DataSnapshot _dataSnapshot) {
												listPas = new ArrayList<>();
												try {
													GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
													for (DataSnapshot _data : _dataSnapshot.getChildren()) {
														HashMap<String, Object> _map = _data.getValue(_ind);
														listPas.add(_map);
													}
												} catch (Exception _e) {
													_e.printStackTrace();
												}
												if (_charSeq.length() > 0) {
													num = listPas.size() - 1;
													len = listPas.size();
													for(int _repeat197 = 0; _repeat197 < (int)(len); _repeat197++) {
														if (listPas.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
															
														} else {
															listPas.remove((int)(num));
														}
														num--;
													}
												}
												gridview6pas.setAdapter(new Gridview6pasAdapter(listPas));
												gridview1veg.setVisibility(View.GONE);
												gridview2fru.setVisibility(View.GONE);
												gridview3food.setVisibility(View.GONE);
												gridview4dat.setVisibility(View.GONE);
												gridview5break.setVisibility(View.GONE);
												gridview6pas.setVisibility(View.VISIBLE);
												gridview7sw.setVisibility(View.GONE);
											}
											@Override
											public void onCancelled(DatabaseError _databaseError) {
											}
										});
									} else {
										if (numSearch == 7) {
											sweets.addListenerForSingleValueEvent(new ValueEventListener() {
												@Override
												public void onDataChange(DataSnapshot _dataSnapshot) {
													listSwe = new ArrayList<>();
													try {
														GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
														for (DataSnapshot _data : _dataSnapshot.getChildren()) {
															HashMap<String, Object> _map = _data.getValue(_ind);
															listSwe.add(_map);
														}
													} catch (Exception _e) {
														_e.printStackTrace();
													}
													if (_charSeq.length() > 0) {
														num = listSwe.size() - 1;
														len = listSwe.size();
														for(int _repeat231 = 0; _repeat231 < (int)(len); _repeat231++) {
															if (listSwe.get((int)num).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
																
															} else {
																listSwe.remove((int)(num));
															}
															num--;
														}
													}
													gridview7sw.setAdapter(new Gridview7swAdapter(listSwe));
													gridview1veg.setVisibility(View.GONE);
													gridview2fru.setVisibility(View.GONE);
													gridview3food.setVisibility(View.GONE);
													gridview4dat.setVisibility(View.GONE);
													gridview5break.setVisibility(View.GONE);
													gridview6pas.setVisibility(View.GONE);
													gridview7sw.setVisibility(View.VISIBLE);
												}
												@Override
												public void onCancelled(DatabaseError _databaseError) {
												}
											});
										}
									}
								}
							}
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				if (_position == 0) {
					gridview1veg.setVisibility(View.VISIBLE);
					gridview2fru.setVisibility(View.GONE);
					gridview3food.setVisibility(View.GONE);
					gridview4dat.setVisibility(View.GONE);
					gridview5break.setVisibility(View.GONE);
					gridview6pas.setVisibility(View.GONE);
					gridview7sw.setVisibility(View.GONE);
					numSearch = 1;
				}
				if (_position == 1) {
					gridview1veg.setVisibility(View.GONE);
					gridview2fru.setVisibility(View.VISIBLE);
					gridview3food.setVisibility(View.GONE);
					gridview4dat.setVisibility(View.GONE);
					gridview5break.setVisibility(View.GONE);
					gridview6pas.setVisibility(View.GONE);
					gridview7sw.setVisibility(View.GONE);
					numSearch = 2;
				}
				if (_position == 2) {
					gridview1veg.setVisibility(View.GONE);
					gridview2fru.setVisibility(View.GONE);
					gridview3food.setVisibility(View.VISIBLE);
					gridview4dat.setVisibility(View.GONE);
					gridview5break.setVisibility(View.GONE);
					gridview6pas.setVisibility(View.GONE);
					gridview7sw.setVisibility(View.GONE);
					numSearch = 3;
				}
				if (_position == 3) {
					gridview1veg.setVisibility(View.GONE);
					gridview2fru.setVisibility(View.GONE);
					gridview3food.setVisibility(View.GONE);
					gridview4dat.setVisibility(View.VISIBLE);
					gridview5break.setVisibility(View.GONE);
					gridview6pas.setVisibility(View.GONE);
					gridview7sw.setVisibility(View.GONE);
					numSearch = 4;
				}
				if (_position == 4) {
					gridview1veg.setVisibility(View.GONE);
					gridview2fru.setVisibility(View.GONE);
					gridview3food.setVisibility(View.GONE);
					gridview4dat.setVisibility(View.GONE);
					gridview5break.setVisibility(View.VISIBLE);
					gridview6pas.setVisibility(View.GONE);
					gridview7sw.setVisibility(View.GONE);
					numSearch = 5;
				}
				if (_position == 5) {
					gridview1veg.setVisibility(View.GONE);
					gridview2fru.setVisibility(View.GONE);
					gridview3food.setVisibility(View.GONE);
					gridview4dat.setVisibility(View.GONE);
					gridview5break.setVisibility(View.GONE);
					gridview6pas.setVisibility(View.VISIBLE);
					gridview7sw.setVisibility(View.GONE);
					numSearch = 6;
				}
				if (_position == 6) {
					gridview1veg.setVisibility(View.GONE);
					gridview2fru.setVisibility(View.GONE);
					gridview3food.setVisibility(View.GONE);
					gridview4dat.setVisibility(View.GONE);
					gridview5break.setVisibility(View.GONE);
					gridview6pas.setVisibility(View.GONE);
					gridview7sw.setVisibility(View.VISIBLE);
					numSearch = 7;
				}
			}
			
			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				if (true) {
					
				}
			}
			
			@Override
			public void onTabReselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
		});
		
		gridview1veg.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listVeg.get((int)_position).get("name").toString());
				i.putExtra("price", listVeg.get((int)_position).get("price").toString());
				i.putExtra("image", listVeg.get((int)_position).get("image").toString());
				i.putExtra("key", listStrVeg.get((int)(_position)));
				i.putExtra("sec", "a");
				startActivity(i);
			}
		});
		
		gridview2fru.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listFru.get((int)_position).get("name").toString());
				i.putExtra("price", listFru.get((int)_position).get("price").toString());
				i.putExtra("image", listFru.get((int)_position).get("image").toString());
				i.putExtra("key", listStrFru.get((int)(_position)));
				i.putExtra("sec", "d");
				startActivity(i);
			}
		});
		
		gridview3food.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listFood.get((int)_position).get("name").toString());
				i.putExtra("price", listFood.get((int)_position).get("price").toString());
				i.putExtra("image", listFood.get((int)_position).get("image").toString());
				i.putExtra("key", listStrFood.get((int)(_position)));
				i.putExtra("sec", "b");
				startActivity(i);
			}
		});
		
		gridview4dat.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listDate.get((int)_position).get("name").toString());
				i.putExtra("price", listDate.get((int)_position).get("price").toString());
				i.putExtra("image", listDate.get((int)_position).get("image").toString());
				i.putExtra("key", listStrDate.get((int)(_position)));
				i.putExtra("sec", "c");
				startActivity(i);
			}
		});
		
		gridview5break.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listBre.get((int)_position).get("name").toString());
				i.putExtra("price", listBre.get((int)_position).get("price").toString());
				i.putExtra("image", listBre.get((int)_position).get("image").toString());
				i.putExtra("key", listStrBre.get((int)(_position)));
				i.putExtra("sec", "e");
				startActivity(i);
			}
		});
		
		gridview6pas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listPas.get((int)_position).get("name").toString());
				i.putExtra("price", listPas.get((int)_position).get("price").toString());
				i.putExtra("image", listPas.get((int)_position).get("image").toString());
				i.putExtra("key", listStrPas.get((int)(_position)));
				i.putExtra("sec", "f");
				startActivity(i);
			}
		});
		
		gridview7sw.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), DetailsActivity.class);
				i.putExtra("name", listSwe.get((int)_position).get("name").toString());
				i.putExtra("price", listSwe.get((int)_position).get("price").toString());
				i.putExtra("image", listSwe.get((int)_position).get("image").toString());
				i.putExtra("key", listStrSwe.get((int)(_position)));
				i.putExtra("sec", "g");
				startActivity(i);
			}
		});
		
		_vegetables_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				vegetables.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listVeg = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listVeg.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listVeg);
						gridview1veg.setAdapter(new Gridview1vegAdapter(listVeg));
						listStrVeg.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		vegetables.addChildEventListener(_vegetables_child_listener);
		
		_food_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				food.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listFood = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listFood.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listFood);
						gridview3food.setAdapter(new Gridview3foodAdapter(listFood));
						listStrFood.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		food.addChildEventListener(_food_child_listener);
		
		_fruit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fruit.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listFru = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listFru.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listFru);
						gridview2fru.setAdapter(new Gridview2fruAdapter(listFru));
						listStrFru.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fruit.addChildEventListener(_fruit_child_listener);
		
		_dates_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				dates.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listDate = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listDate.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listDate);
						gridview4dat.setAdapter(new Gridview4datAdapter(listDate));
						listStrDate.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dates.addChildEventListener(_dates_child_listener);
		
		_breakfast_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				breakfast.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listBre = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listBre.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listBre);
						gridview5break.setAdapter(new Gridview5breakAdapter(listBre));
						listStrBre.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		breakfast.addChildEventListener(_breakfast_child_listener);
		
		_pastries_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				pastries.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listPas = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listPas.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listPas);
						gridview6pas.setAdapter(new Gridview6pasAdapter(listPas));
						listStrPas.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pastries.addChildEventListener(_pastries_child_listener);
		
		_sweets_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				sweets.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listSwe = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listSwe.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(listSwe);
						gridview7sw.setAdapter(new Gridview7swAdapter(listSwe));
						listStrSwe.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sweets.addChildEventListener(_sweets_child_listener);
	}
	
	private void initializeLogic() {
		tablayout1.addTab(tablayout1.newTab().setText("المخضر 🥦"));
		tablayout1.addTab(tablayout1.newTab().setText("الفواكه 🍒"));
		tablayout1.addTab(tablayout1.newTab().setText("الغذائية 🧀"));
		tablayout1.addTab(tablayout1.newTab().setText("المشروبات 🧋"));
		tablayout1.addTab(tablayout1.newTab().setText("الريوك 🍳"));
		tablayout1.addTab(tablayout1.newTab().setText("المعجنات 🥞"));
		tablayout1.addTab(tablayout1.newTab().setText("الحلويات 🍟"));
		tablayout1.setTabTextColors(0xFFE0E0E0, 0xFFFFFFFF);
		tablayout1.setTabRippleColor(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_pressed}}, 
		
		new int[] {0xFFA5D6A7}));
		tablayout1.setSelectedTabIndicatorColor(0xFFFFE082);
		gridview1veg.setVisibility(View.VISIBLE);
		gridview2fru.setVisibility(View.GONE);
		gridview3food.setVisibility(View.GONE);
		gridview4dat.setVisibility(View.GONE);
		gridview5break.setVisibility(View.GONE);
		gridview6pas.setVisibility(View.GONE);
		gridview7sw.setVisibility(View.GONE);
		numSearch = 1;
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		_ClickEffect(imageview1);
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear2.setBackgroundColor(0xFFFFFFFF);
			} else {
				linear2.setBackgroundColor(0xFF0D1F29);
			}
		}
	}
	
	public void _ClickEffect(final View _view) {
		TypedValue typedValue = new TypedValue();
		
		getApplicationContext().getTheme().resolveAttribute(16843868, typedValue, true);
		
		_view.setBackgroundResource(typedValue.resourceId);
		
		_view.setClickable(true);
	}
	
	public class Gridview1vegAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1vegAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listVeg.get((int)_position).get("name").toString());
			textview2.setText(listVeg.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listVeg.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	public class Gridview2fruAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview2fruAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listFru.get((int)_position).get("name").toString());
			textview2.setText(listFru.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listFru.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	public class Gridview3foodAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview3foodAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listFood.get((int)_position).get("name").toString());
			textview2.setText(listFood.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listFood.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	public class Gridview4datAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview4datAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listDate.get((int)_position).get("name").toString());
			textview2.setText(listDate.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listDate.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	public class Gridview5breakAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview5breakAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listBre.get((int)_position).get("name").toString());
			textview2.setText(listBre.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listBre.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	public class Gridview6pasAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview6pasAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listPas.get((int)_position).get("name").toString());
			textview2.setText(listPas.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listPas.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	public class Gridview7swAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview7swAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(listSwe.get((int)_position).get("name").toString());
			textview2.setText(listSwe.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listSwe.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}