package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.bumptech.glide.Glide;
import com.goodiebag.pinview.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class VegetablesActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private ArrayList<HashMap<String, Object>> itemssi = new ArrayList<>();
	private ArrayList<String> liststr = new ArrayList<>();
	private ArrayList<String> foodListStr = new ArrayList<>();
	private ArrayList<String> datesListStr = new ArrayList<>();
	private ArrayList<String> fruitListStr = new ArrayList<>();
	private ArrayList<String> breakfastListStr = new ArrayList<>();
	private ArrayList<String> pastriesListStr = new ArrayList<>();
	private ArrayList<String> sweetsListStr = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview1;
	private GridView gridview1;
	
	private Intent i = new Intent();
	private DatabaseReference vegetables = _firebase.getReference("vegetables");
	private ChildEventListener _vegetables_child_listener;
	private DatabaseReference food = _firebase.getReference("food");
	private ChildEventListener _food_child_listener;
	private DatabaseReference dates = _firebase.getReference("dates");
	private ChildEventListener _dates_child_listener;
	private DatabaseReference fruit = _firebase.getReference("fruit");
	private ChildEventListener _fruit_child_listener;
	private SharedPreferences shop;
	private DatabaseReference breakfast = _firebase.getReference("breakfast");
	private ChildEventListener _breakfast_child_listener;
	private DatabaseReference pastries = _firebase.getReference("pastries");
	private ChildEventListener _pastries_child_listener;
	private DatabaseReference sweets = _firebase.getReference("sweets");
	private ChildEventListener _sweets_child_listener;
	private SharedPreferences mode;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.vegetables);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		textview1 = findViewById(R.id.textview1);
		gridview1 = findViewById(R.id.gridview1);
		shop = getSharedPreferences("shop", Activity.MODE_PRIVATE);
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (getIntent().getStringExtra("sec").equals("a")) {
					i.setClass(getApplicationContext(), DetailsActivity.class);
					i.putExtra("name", itemssi.get((int)_position).get("name").toString());
					i.putExtra("price", itemssi.get((int)_position).get("price").toString());
					i.putExtra("image", itemssi.get((int)_position).get("image").toString());
					i.putExtra("key", liststr.get((int)(_position)));
					i.putExtra("sec", "a");
					startActivity(i);
				} else {
					if (getIntent().getStringExtra("sec").equals("b")) {
						i.setClass(getApplicationContext(), DetailsActivity.class);
						i.putExtra("name", itemssi.get((int)_position).get("name").toString());
						i.putExtra("price", itemssi.get((int)_position).get("price").toString());
						i.putExtra("image", itemssi.get((int)_position).get("image").toString());
						i.putExtra("key", foodListStr.get((int)(_position)));
						i.putExtra("sec", "b");
						startActivity(i);
					} else {
						if (getIntent().getStringExtra("sec").equals("c")) {
							i.setClass(getApplicationContext(), DetailsActivity.class);
							i.putExtra("name", itemssi.get((int)_position).get("name").toString());
							i.putExtra("price", itemssi.get((int)_position).get("price").toString());
							i.putExtra("image", itemssi.get((int)_position).get("image").toString());
							i.putExtra("key", datesListStr.get((int)(_position)));
							i.putExtra("sec", "c");
							startActivity(i);
						} else {
							if (getIntent().getStringExtra("sec").equals("d")) {
								i.setClass(getApplicationContext(), DetailsActivity.class);
								i.putExtra("name", itemssi.get((int)_position).get("name").toString());
								i.putExtra("price", itemssi.get((int)_position).get("price").toString());
								i.putExtra("image", itemssi.get((int)_position).get("image").toString());
								i.putExtra("key", fruitListStr.get((int)(_position)));
								i.putExtra("sec", "d");
								startActivity(i);
							} else {
								if (getIntent().getStringExtra("sec").equals("e")) {
									i.setClass(getApplicationContext(), DetailsActivity.class);
									i.putExtra("name", itemssi.get((int)_position).get("name").toString());
									i.putExtra("price", itemssi.get((int)_position).get("price").toString());
									i.putExtra("image", itemssi.get((int)_position).get("image").toString());
									i.putExtra("key", breakfastListStr.get((int)(_position)));
									i.putExtra("sec", "e");
									startActivity(i);
								} else {
									if (getIntent().getStringExtra("sec").equals("f")) {
										i.setClass(getApplicationContext(), DetailsActivity.class);
										i.putExtra("name", itemssi.get((int)_position).get("name").toString());
										i.putExtra("price", itemssi.get((int)_position).get("price").toString());
										i.putExtra("image", itemssi.get((int)_position).get("image").toString());
										i.putExtra("key", pastriesListStr.get((int)(_position)));
										i.putExtra("sec", "f");
										startActivity(i);
									} else {
										if (getIntent().getStringExtra("sec").equals("g")) {
											i.setClass(getApplicationContext(), DetailsActivity.class);
											i.putExtra("name", itemssi.get((int)_position).get("name").toString());
											i.putExtra("price", itemssi.get((int)_position).get("price").toString());
											i.putExtra("image", itemssi.get((int)_position).get("image").toString());
											i.putExtra("key", sweetsListStr.get((int)(_position)));
											i.putExtra("sec", "g");
											startActivity(i);
										}
									}
								}
							}
						}
					}
				}
			}
		});
		
		_vegetables_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				liststr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		vegetables.addChildEventListener(_vegetables_child_listener);
		
		_food_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				foodListStr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		food.addChildEventListener(_food_child_listener);
		
		_dates_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				datesListStr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dates.addChildEventListener(_dates_child_listener);
		
		_fruit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fruitListStr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fruit.addChildEventListener(_fruit_child_listener);
		
		_breakfast_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				breakfastListStr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		breakfast.addChildEventListener(_breakfast_child_listener);
		
		_pastries_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				pastriesListStr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pastries.addChildEventListener(_pastries_child_listener);
		
		_sweets_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				sweetsListStr.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sweets.addChildEventListener(_sweets_child_listener);
	}
	
	private void initializeLogic() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		if (getIntent().getStringExtra("sec").equals("a")) {
			textview1.setText("قسم المخضر 🍅");
			vegetables.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (getIntent().getStringExtra("sec").equals("b")) {
			textview1.setText("قسم الغذائية 🛒");
			food.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (getIntent().getStringExtra("sec").equals("c")) {
			textview1.setText("قسم المشروبات🧋");
			dates.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (getIntent().getStringExtra("sec").equals("d")) {
			textview1.setText("قسم الفواكه 🍎");
			fruit.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (getIntent().getStringExtra("sec").equals("e")) {
			textview1.setText("قسم الريوك 🥚");
			breakfast.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (getIntent().getStringExtra("sec").equals("f")) {
			textview1.setText("قسم المعجنات🥞");
			pastries.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (getIntent().getStringExtra("sec").equals("g")) {
			textview1.setText("قسم الحلويات 🍟");
			sweets.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					itemssi = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							itemssi.add(_map);
						}
					} catch (Exception _e) {
						_e.printStackTrace();
					}
					gridview1.setAdapter(new Gridview1Adapter(itemssi));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear2.setBackgroundColor(0xFFFFFFFF);
			} else {
				linear2.setBackgroundColor(0xFF0D1F29);
			}
		}
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(itemssi.get((int)_position).get("name").toString());
			textview2.setText(itemssi.get((int)_position).get("price").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(itemssi.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}