package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.core.widget.NestedScrollView;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.bumptech.glide.Glide;
import com.goodiebag.pinview.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import androidx.core.widget.NestedScrollView;

public class MainpageFragmentActivity extends Fragment {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private ArrayList<HashMap<String, Object>> listproduct = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> vegList = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> fruitList = new ArrayList<>();
	private ArrayList<String> lsist = new ArrayList<>();
	private ArrayList<String> lsishsh = new ArrayList<>();
	private ArrayList<String> usrKey = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> bannerList = new ArrayList<>();
	
	private NestedScrollView vscroll1;
	private LinearLayout linear1;
	private CardView cardview1;
	private LinearLayout linear2;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear13;
	private RecyclerView recyclerview1;
	private GridView gridview1;
	private LinearLayout linear14;
	private RecyclerView recyclerview2;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear6;
	private LinearLayout linear4;
	private LinearLayout linear19;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private LinearLayout linear17;
	private LinearLayout linear15;
	private LinearLayout linear11;
	private LinearLayout linear5;
	private TextView textview3;
	private ImageView imageview2;
	private LinearLayout linear20;
	private TextView textview13;
	private ImageView imageview8;
	private LinearLayout linear8;
	private TextView textview4;
	private ImageView imageview3;
	private LinearLayout linear10;
	private TextView textview5;
	private ImageView imageview4;
	private LinearLayout linear18;
	private TextView textview12;
	private ImageView imageview7;
	private LinearLayout linear16;
	private TextView textview11;
	private ImageView imageview6;
	private LinearLayout linear12;
	private TextView textview6;
	private ImageView imageview5;
	private TextView textview7;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	
	private Intent i = new Intent();
	private DatabaseReference vegetables = _firebase.getReference("vegetables");
	private ChildEventListener _vegetables_child_listener;
	private DatabaseReference fruit = _firebase.getReference("fruit");
	private ChildEventListener _fruit_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private DatabaseReference bannerDB = _firebase.getReference("bannerDB");
	private ChildEventListener _bannerDB_child_listener;
	private SharedPreferences mode;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.mainpage_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		vscroll1 = _view.findViewById(R.id.vscroll1);
		linear1 = _view.findViewById(R.id.linear1);
		cardview1 = _view.findViewById(R.id.cardview1);
		linear2 = _view.findViewById(R.id.linear2);
		hscroll1 = _view.findViewById(R.id.hscroll1);
		linear13 = _view.findViewById(R.id.linear13);
		recyclerview1 = _view.findViewById(R.id.recyclerview1);
		gridview1 = _view.findViewById(R.id.gridview1);
		linear14 = _view.findViewById(R.id.linear14);
		recyclerview2 = _view.findViewById(R.id.recyclerview2);
		imageview1 = _view.findViewById(R.id.imageview1);
		textview1 = _view.findViewById(R.id.textview1);
		linear6 = _view.findViewById(R.id.linear6);
		linear4 = _view.findViewById(R.id.linear4);
		linear19 = _view.findViewById(R.id.linear19);
		linear7 = _view.findViewById(R.id.linear7);
		linear9 = _view.findViewById(R.id.linear9);
		linear17 = _view.findViewById(R.id.linear17);
		linear15 = _view.findViewById(R.id.linear15);
		linear11 = _view.findViewById(R.id.linear11);
		linear5 = _view.findViewById(R.id.linear5);
		textview3 = _view.findViewById(R.id.textview3);
		imageview2 = _view.findViewById(R.id.imageview2);
		linear20 = _view.findViewById(R.id.linear20);
		textview13 = _view.findViewById(R.id.textview13);
		imageview8 = _view.findViewById(R.id.imageview8);
		linear8 = _view.findViewById(R.id.linear8);
		textview4 = _view.findViewById(R.id.textview4);
		imageview3 = _view.findViewById(R.id.imageview3);
		linear10 = _view.findViewById(R.id.linear10);
		textview5 = _view.findViewById(R.id.textview5);
		imageview4 = _view.findViewById(R.id.imageview4);
		linear18 = _view.findViewById(R.id.linear18);
		textview12 = _view.findViewById(R.id.textview12);
		imageview7 = _view.findViewById(R.id.imageview7);
		linear16 = _view.findViewById(R.id.linear16);
		textview11 = _view.findViewById(R.id.textview11);
		imageview6 = _view.findViewById(R.id.imageview6);
		linear12 = _view.findViewById(R.id.linear12);
		textview6 = _view.findViewById(R.id.textview6);
		imageview5 = _view.findViewById(R.id.imageview5);
		textview7 = _view.findViewById(R.id.textview7);
		textview8 = _view.findViewById(R.id.textview8);
		textview9 = _view.findViewById(R.id.textview9);
		textview10 = _view.findViewById(R.id.textview10);
		mode = getContext().getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getContext().getApplicationContext(), DetailsActivity.class);
				startActivity(i);
			}
		});
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "d");
				startActivity(i);
			}
		});
		
		linear19.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "e");
				startActivity(i);
			}
		});
		
		linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "a");
				startActivity(i);
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "c");
				startActivity(i);
			}
		});
		
		linear17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "f");
				startActivity(i);
			}
		});
		
		linear15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "g");
				startActivity(i);
			}
		});
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "b");
				startActivity(i);
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "a");
				startActivity(i);
			}
		});
		
		textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getContext().getApplicationContext(), VegetablesActivity.class);
				i.putExtra("sec", "d");
				startActivity(i);
			}
		});
		
		_vegetables_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				vegetables.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						vegList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								vegList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(vegList));
						lsist.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				vegetables.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						vegList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								vegList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(vegList));
						lsist.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				vegetables.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						vegList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								vegList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(vegList));
						lsist.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				SketchwareUtil.showMessage(getContext().getApplicationContext(), _errorMessage);
			}
		};
		vegetables.addChildEventListener(_vegetables_child_listener);
		
		_fruit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fruit.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						fruitList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								fruitList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview2.setAdapter(new Recyclerview2Adapter(fruitList));
						lsishsh.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fruit.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						fruitList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								fruitList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview2.setAdapter(new Recyclerview2Adapter(fruitList));
						lsishsh.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fruit.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						fruitList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								fruitList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview2.setAdapter(new Recyclerview2Adapter(fruitList));
						lsishsh.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fruit.addChildEventListener(_fruit_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usrKey.add(_childKey);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_bannerDB_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				bannerDB.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						bannerList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								bannerList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Glide.with(getContext().getApplicationContext()).load(Uri.parse(bannerList.get((int)0).get("banner").toString())).into(imageview1);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				bannerDB.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						bannerList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								bannerList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						Glide.with(getContext().getApplicationContext()).load(Uri.parse(bannerList.get((int)0).get("banner").toString())).into(imageview1);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		bannerDB.addChildEventListener(_bannerDB_child_listener);
	}
	
	private void initializeLogic() {
		textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview8.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview11.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview12.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		for(int _repeat24 = 0; _repeat24 < (int)(4); _repeat24++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("a", "");
				listproduct.add(_item);
			}
		}
		gridview1.setAdapter(new Gridview1Adapter(listproduct));
		recyclerview1.setLayoutManager(new LinearLayoutManager(getContext()));
		recyclerview1.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview2.setLayoutManager(new LinearLayoutManager(getContext()));
		recyclerview2.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		textview10.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
		textview9.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 0);
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear20.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear18.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear1.setBackgroundColor(0xFFFFFFFF);
				textview1.setTextColor(0xFF000000);
				textview3.setTextColor(0xFF000000);
				textview13.setTextColor(0xFF000000);
				textview4.setTextColor(0xFF000000);
				textview5.setTextColor(0xFF000000);
				textview12.setTextColor(0xFF000000);
				textview11.setTextColor(0xFF000000);
				textview6.setTextColor(0xFF000000);
				textview8.setTextColor(0xFF000000);
				textview10.setTextColor(0xFF000000);
				imageview1.setBackgroundColor(0xFFF2F3F5);
			} else {
				linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear20.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear18.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear1.setBackgroundColor(0xFF0D1F29);
				textview1.setTextColor(0xFFFFFFFF);
				textview3.setTextColor(0xFFFFFFFF);
				textview13.setTextColor(0xFFFFFFFF);
				textview4.setTextColor(0xFFFFFFFF);
				textview5.setTextColor(0xFFFFFFFF);
				textview12.setTextColor(0xFFFFFFFF);
				textview11.setTextColor(0xFFFFFFFF);
				textview6.setTextColor(0xFFFFFFFF);
				textview8.setTextColor(0xFFFFFFFF);
				textview10.setTextColor(0xFFFFFFFF);
				imageview1.setBackgroundColor(0xFF1A2A37);
			}
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.item_shape, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			textview3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(vegList.get((int)_position).get("name").toString());
			textview2.setText(vegList.get((int)_position).get("price").toString());
			Glide.with(getContext().getApplicationContext()).load(Uri.parse(vegList.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getContext().getApplicationContext(), DetailsActivity.class);
					i.putExtra("name", vegList.get((int)_position).get("name").toString());
					i.putExtra("price", vegList.get((int)_position).get("price").toString());
					i.putExtra("image", vegList.get((int)_position).get("image").toString());
					i.putExtra("key", lsist.get((int)(_position)));
					i.putExtra("sec", "a");
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.item_shape, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
			textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			if (_position == 0) {
				textview1.setText("طماطة");
				textview2.setText("750 دينار");
				imageview1.setImageResource(R.drawable.tomatoes_product);
			}
			if (_position == 1) {
				textview1.setText("بتيتة");
				textview2.setText("1000 دينار");
				imageview1.setImageResource(R.drawable.potato);
			}
			if (_position == 2) {
				textview1.setText("بصل");
				textview2.setText("500 دينار");
				imageview1.setImageResource(R.drawable.onion);
			}
			if (_position == 3) {
				textview1.setText("طماطة");
				textview2.setText("750 دينار");
				imageview1.setImageResource(R.drawable.tomatoes_product);
			}
			
			return _view;
		}
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.item_shape, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			textview3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/cairoregular.ttf"), 1);
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
			textview1.setText(fruitList.get((int)_position).get("name").toString());
			textview2.setText(fruitList.get((int)_position).get("price").toString());
			Glide.with(getContext().getApplicationContext()).load(Uri.parse(fruitList.get((int)_position).get("image").toString())).into(imageview1);
			if (mode.contains("mode")) {
				if (mode.getString("mode", "").equals("light")) {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF2F3F5));
					textview1.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
				} else {
					linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1A2A37));
					textview1.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
				}
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getContext().getApplicationContext(), DetailsActivity.class);
					i.putExtra("name", fruitList.get((int)_position).get("name").toString());
					i.putExtra("price", fruitList.get((int)_position).get("price").toString());
					i.putExtra("image", fruitList.get((int)_position).get("image").toString());
					i.putExtra("key", lsishsh.get((int)(_position)));
					i.putExtra("sec", "d");
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}