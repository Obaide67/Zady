package com.zady;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.asynclayoutinflater.*;
import androidx.cardview.*;
import androidx.constraintlayout.widget.*;
import androidx.coordinatorlayout.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.documentfile.*;
import androidx.drawerlayout.*;
import androidx.dynamicanimation.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.legacy.coreui.*;
import androidx.legacy.coreutils.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.localbroadcastmanager.*;
import androidx.print.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.*;
import androidx.savedstate.*;
import androidx.slidingpanelayout.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.transition.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import androidx.viewpager2.*;
import com.bumptech.glide.Glide;
import com.goodiebag.pinview.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class DetailsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String phone = "";
	private String message = "";
	private HashMap<String, Object> orD = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> ordList = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> orderCheck = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear9;
	private TextView textview5;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear10;
	private ImageView imageview1;
	private LinearLayout linear11;
	private ImageView imageview4;
	private LinearLayout linear8;
	private TextView textview2;
	private LinearLayout linear4;
	private LinearLayout linear7;
	private TextView textview1;
	private ImageView imageview3;
	private ImageView imageview2;
	private TextView textview3;
	private Button button1;
	private Button button2;
	
	private Intent iii = new Intent();
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private SharedPreferences shop;
	private SharedPreferences mode;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.details);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear9 = findViewById(R.id.linear9);
		textview5 = findViewById(R.id.textview5);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear10 = findViewById(R.id.linear10);
		imageview1 = findViewById(R.id.imageview1);
		linear11 = findViewById(R.id.linear11);
		imageview4 = findViewById(R.id.imageview4);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		linear4 = findViewById(R.id.linear4);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		imageview3 = findViewById(R.id.imageview3);
		imageview2 = findViewById(R.id.imageview2);
		textview3 = findViewById(R.id.textview3);
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		shop = getSharedPreferences("shop", Activity.MODE_PRIVATE);
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (getIntent().getStringExtra("sec").equals("a") || getIntent().getStringExtra("sec").equals("d")) {
					String text = textview2.getText().toString().trim();
					
					// استبدال الفاصلة العربية إن وجدت
					text = text.replace("٫", ".");
					
					if (text.isEmpty()) text = "0";
					
					try {
						    double value = Double.parseDouble(text);
						
						    if (value == 0.5) {
							        // لا تفعل شيء
							    } else {
							        value = value - 0.5;
							        textview2.setText(String.format(Locale.US, "%.1f", value));
							    }
						
					} catch (NumberFormatException e) {
						    // إذا حصل خطأ، أعد تعيين القيمة إلى 0.0
						    textview2.setText("0.0");
					}
				} else {
					String text = textview2.getText().toString().trim();
					
					// استبدال الفاصلة العربية إن وجدت
					text = text.replace("٫", ".");
					
					if (text.isEmpty()) text = "0";
					
					try {
						    double value = Double.parseDouble(text);
						
						    if (value == 1.0) {
							        // لا تفعل شيء
							    } else {
							        value = value - 1.0;
							        textview2.setText(String.format(Locale.US, "%.1f", value));
							    }
						
					} catch (NumberFormatException e) {
						    // إذا حصل خطأ، أعد تعيين القيمة إلى 0.0
						    textview2.setText("0.0");
					}
				}
			}
		});
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (getIntent().getStringExtra("sec").equals("a") || getIntent().getStringExtra("sec").equals("d")) {
					String text = textview2.getText().toString().trim();
					
					// استبدال الفاصلة العربية (٫) بالنقطة (.)
					text = text.replace("٫", ".");
					
					// إذا النص فارغ، نخليه "0"
					if (text.isEmpty()) text = "0";
					
					try {
						    double value = Double.parseDouble(text);
						    value = value + 0.5;
						
						    // نعرض الرقم بتنسيق عشري واحد مثل 1.0 أو 0.5
						    textview2.setText(String.format(Locale.US, "%.1f", value));
						
					} catch (NumberFormatException e) {
						    // في حال النص غير رقمي لأي سبب
						    textview2.setText("0.0");
					}
				} else {
					String text = textview2.getText().toString().trim();
					
					// استبدال الفاصلة العربية (٫) بالنقطة (.)
					text = text.replace("٫", ".");
					
					// إذا النص فارغ، نخليه "0"
					if (text.isEmpty()) text = "0";
					
					try {
						    double value = Double.parseDouble(text);
						    value = value + 1.0;
						
						    // نعرض الرقم بتنسيق عشري واحد مثل 1.0 أو 0.5
						    textview2.setText(String.format(Locale.US, "%.1f", value));
						
					} catch (NumberFormatException e) {
						    // في حال النص غير رقمي لأي سبب
						    textview2.setText("0.0");
					}
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (String.valueOf((long)(Double.parseDouble(textview2.getText().toString()))).equals("0") || String.valueOf((long)(Double.parseDouble(textview2.getText().toString()))).equals("0.0")) {
					SketchwareUtil.showMessage(getApplicationContext(), "لا يمكن طلب قيمة فارغة!\nحدد العدد او الكيلو");
				} else {
					SharedPreferences shop = getSharedPreferences("shop", MODE_PRIVATE);
					
					// 🟢 أولاً: استرجع القائمة القديمة إن وجدت
					String json = shop.getString("order", "[]");
					ArrayList<HashMap<String, String>> ordList = new Gson().fromJson(
					    json,
					    new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, String>>>(){}.getType()
					);
					
					// 🟢 ثم أضف الطلب الجديد
					HashMap<String, String> orD = new HashMap<>();
					orD.put("name", getIntent().getStringExtra("name"));
					orD.put("price", getIntent().getStringExtra("price"));
					orD.put("quantity", textview2.getText().toString());
					orD.put("total", String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("price")) * Double.parseDouble(textview2.getText().toString()))));
					ordList.add(orD);
					
					// 🟢 وأخيرًا: احفظ القائمة مجددًا
					shop.edit().putString("order", new Gson().toJson(ordList)).commit();
					
					// جلب النص المحفوظ (القائمة على شكل JSON)
					String json1 = shop.getString("order", "");
					
					// التحقق أولاً من أن المفتاح موجود وغير فارغ
					if (!json1.isEmpty()) {
						    // تحويل JSON إلى ArrayList من HashMap
						    java.lang.reflect.Type type = new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType();
						    ArrayList<HashMap<String, Object>> orderList = new com.google.gson.Gson().fromJson(json1, type);
						
						    // حساب عدد العناصر
						    int count = orderList.size();
						
						    // مثال: عرض العدد في TextView
						    button1.setText(" اضافة الى السلة: " + count);
					} else {
						    button1.setText("اضافة الى السلة");
					}
					SketchwareUtil.showMessage(getApplicationContext(), "تمت الاضافة الى السلة");
					finish();
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!(orderCheck.size() == 0)) {
					iii.setClass(getApplicationContext(), SendDetailsActivity.class);
					iii.putExtra("name", getIntent().getStringExtra("name"));
					iii.putExtra("price", getIntent().getStringExtra("price"));
					iii.putExtra("quantity", textview2.getText().toString());
					startActivity(iii);
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "السلة فارغة!");
				}
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
	}
	
	private void initializeLogic() {
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
		button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF23AB49));
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		button2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		_WidgetAnimation(linear11);
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("image"))).into(imageview1);
		textview1.setText(getIntent().getStringExtra("name"));
		textview3.setText(getIntent().getStringExtra("price"));
		SharedPreferences shop = getSharedPreferences("shop", MODE_PRIVATE);
		
		// جلب النص المحفوظ (القائمة على شكل JSON)
		String json = shop.getString("order", "");
		
		// التحقق أولاً من أن المفتاح موجود وغير فارغ
		if (!json.isEmpty()) {
			    // تحويل JSON إلى ArrayList من HashMap
			    java.lang.reflect.Type type = new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType();
			    ArrayList<HashMap<String, Object>> orderList = new com.google.gson.Gson().fromJson(json, type);
			
			    // حساب عدد العناصر
			    int count = orderList.size();
			
			    // مثال: عرض العدد في TextView
			    button1.setText(" اضافة الى السلة: " + count);
		} else {
			    button1.setText("اضافة الى السلة");
		}
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/cairoregular.ttf"), 1);
		if (shop.contains("order")) {
			orderCheck = new Gson().fromJson(shop.getString("order", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		} else {
			
		}
		if (mode.contains("mode")) {
			if (mode.getString("mode", "").equals("light")) {
				linear1.setBackgroundColor(0xFFFFFFFF);
				_SET_LINEAR_LAYOUTS(0, 0, 45, 45, "#F2F3F5", "#F2F3F5", 0, linear2);
				linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF2F3F5));
				linear11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
				if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
					final Window window = DetailsActivity.this.getWindow();
					window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
					window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
					window.setStatusBarColor(0xFFF2F3F5);
				}
				textview1.setTextColor(0xFF000000);
				textview2.setTextColor(0xFF000000);
				textview5.setTextColor(0xFF000000);
				button1.setTextColor(0xFF000000);
				imageview3.setImageResource(R.drawable.icon_minus_round);
				imageview4.setImageResource(R.drawable.icon_arrow_back_ios_round1);
			} else {
				linear1.setBackgroundColor(0xFF0D1F29);
				_SET_LINEAR_LAYOUTS(0, 0, 45, 45, "#1A2A37", "#1A2A37", 0, linear2);
				linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF1A2A37));
				linear11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF0D1F29));
				if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
					final Window window = DetailsActivity.this.getWindow();
					window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
					window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
					window.setStatusBarColor(0xFF1A2A37);
				}
				textview1.setTextColor(0xFFFFFFFF);
				textview2.setTextColor(0xFFFFFFFF);
				textview5.setTextColor(0xFFFFFFFF);
				button1.setTextColor(0xFFFFFFFF);
				imageview3.setImageResource(R.drawable.icon_minus_round_white);
				imageview4.setImageResource(R.drawable.icon_arrow_back_ios_round_white);
			}
		}
	}
	
	public void _WidgetAnimation(final View _view) {
		_view.setOnTouchListener(new View.OnTouchListener() {
			    private final float scaleDown = 0.9f; // نسبة التصغير عند الضغط
			    private final long animationDuration = 150; // مدة التأثير بالمللي ثانية
			
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        switch (event.getAction()) {
					            case MotionEvent.ACTION_DOWN: // عند الضغط
					                animateView(v, scaleDown, 0.8f); // تصغير بسيط + تعتيم طفيف
					                return true;
					
					            case MotionEvent.ACTION_UP: // عند رفع الأصبع
					                animateView(v, 1f, 1f); // إعادة الحجم والتعتيم للحالة الطبيعية
					                v.performClick(); // تنفيذ onClick بعد رفع الإصبع
					                return false; // السماح بتمرير الحدث لـ onClick
					
					            case MotionEvent.ACTION_CANCEL:
					                animateView(v, 1f, 1f); // إعادة الحجم عند إلغاء اللمس
					                return false;
					
					            case MotionEvent.ACTION_MOVE:
					                return false;
					        }
				        return false;
				    }
			
			    private void animateView(View v, float scale, float alpha) {
				        v.animate()
				                .scaleX(scale)
				                .scaleY(scale)
				                .alpha(alpha)
				                .setDuration(animationDuration)
				                .setInterpolator(new DecelerateInterpolator())
				                .start();
				    }
		});
	}
	
	
	public void _SET_LINEAR_LAYOUTS(final double _r1, final double _r2, final double _r3, final double _r4, final String _lcolor, final String _scolor, final double _swidth, final View _view) {
		Double tlr = _r1;
		Double trr = _r2;
		Double blr = _r3;
		Double brr = _r4;
		Double sw = _swidth;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {tlr.floatValue(),tlr.floatValue(), trr.floatValue(),trr.floatValue(), blr.floatValue(),blr.floatValue(), brr.floatValue(),brr.floatValue()});
		s.setColor(Color.parseColor(_lcolor));
		s.setStroke(sw.intValue(), Color.parseColor(_scolor));
		_view.setBackground(s);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}